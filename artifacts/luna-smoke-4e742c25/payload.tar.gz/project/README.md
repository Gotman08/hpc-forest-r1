# R1 — reconstruction isolée du moteur

Ce projet reprend la version figée de R1 utilisée pour les campagnes historiques.
Les 89 fichiers de départ ont été vérifiés avant copie. Le reçu est dans
docs/provenance-baseline.json ; la documentation originale est conservée dans
docs/reference/README-original.md.

Le travail porte sur le code : simplification, helpers partagés et correction des
validations. La méthode de recherche reste celle de R1 : mère de préparation puis
de synthèse, rôles A/B/C et intégration G, véritable TreeQuest AB-MCTS-A 0.3.2,
évaluateur externe et confirmations séparées. La lecture du code ne lance aucun
modèle, aucune campagne ni allocation.

## Organisation

| Emplacement | Responsabilité |
| --- | --- |
| src/hpc_forest/controller.py | Ordonnancement et vie de la campagne |
| src/hpc_forest/search.py | TreeQuest et persistance ask/tell |
| src/hpc_forest/mother.py | Préparation et synthèse de la mère |
| src/hpc_forest/node_harness.py | Développement borné d'un candidat |
| src/hpc_forest/evaluator.py | Compilation, correction et mesures |
| src/hpc_forest/registry.py | Registre, réservations et consommation |
| src/hpc_forest/support/ | Sources bornées, échéances et validation numérique |
| tests/ | Régressions historiques et nouvelles gardes |
| tools/check.py | Vérification locale avec imports du nouveau projet |
| tools/prepare_smoke.py | Préparation locale d'un nouveau pilote Luna MAX |
| tools/native_smoke.py | Pilote court ARM64 et worker local lié à sa seule session |
| docs/ | Provenance et décisions de reconstruction |
| artifacts/ | Reçus locaux de vérification, exclus des sources |

## Développement

Python 3.11 ou supérieur et les dépendances de pyproject.toml sont nécessaires.
Utiliser un environnement Python propre au projet pour toute installation future.
Le module importé reste hpc_forest pour conserver les interfaces existantes ; la
distribution et la commande installée se nomment hpc-forest-r1.

Le point d'entrée de vérification est tools/check.py. Il vérifie Ruff puis les
tests, impose les sources de ce dossier aux sous-processus Python, et écrit ses
rapports dans un dossier neuf sous artifacts/. Les tests utilisent des doubles de
transport ; ils n'appellent pas de modèle hébergé.

Le contrôle local complet de la reconstruction a donné 248 réussites et trois
sauts faute de GCC/G++. La wheel reconstruite a été comparée aux 38 fichiers du
paquet. Les reçus détaillés sont conservés dans artifacts/.

À la demande explicite de l'utilisateur, un pilote distinct teste les vrais appels
Luna MAX sur la multiplication de matrices embarquée : une mission par rôle
A/B/C/G, deux interventions de la mère, réparations bornées et confirmation
indépendante. Son budget court et sa tâche synthétique servent au contrôle de la
chaîne ; ils ne constituent pas une campagne comparable aux résultats R1 anciens.

## Limites à conserver

Une réussite des tests logiciels ne démontre aucun gain HPC, aucune activation
native sur ROMEO et aucune conformité universelle aux énoncés. La conformité
algorithmique stricte d'un sujet demande son propre contrat : comparer les sorties
ne suffit notamment pas à imposer l'utilisation de quicksort.

Les résultats, caches, sessions, autorisations et intentions historiques ne sont
pas importés. Les transports hérités et les scripts d'exemples restent du code de
référence ; leur présence n'autorise pas leur exécution ni la réutilisation d'une
ancienne identité de campagne.
