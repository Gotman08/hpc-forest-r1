"""Prepare a fresh local payload; neither submits a job nor calls a model."""
from __future__ import annotations

import json
import tarfile
import time
import uuid
from pathlib import Path

from native_smoke import EFFORT, MODEL, SCOPE

from hpc_forest.core import atomic_json, file_digest


def main():
    project = Path(__file__).resolve().parent.parent
    session = uuid.uuid4().hex
    destination = project / "artifacts" / ("luna-smoke-" + session[:8])
    destination.mkdir(exist_ok=False)
    remote_root = "/scratch_p/nimarano/hpc-forest-r1-pilot-" + session
    plan = {"scope": SCOPE, "session_id": session, "model": MODEL, "effort": EFFORT,
            "subject": "matmul", "child_missions": 4, "mother_calls": 2,
            "wall_seconds": 900, "token_budget": 1500000,
            "maximum_calls_including_repairs": 14, "cores": 4, "gpus": 0,
            "remote_root": remote_root, "created_at": time.time(),
            "purpose": "mechanical smoke; shortened schedule; no R1 comparison",
            "historical_candidates_imported": False}
    atomic_json(destination / "plan.json", plan)
    files = []
    for relative in ("src", "tests", "tools", "examples/matmul"):
        files.extend(path for path in (project / relative).rglob("*")
                     if path.is_file() and "__pycache__" not in path.parts)
    files.extend(project / name for name in ("pyproject.toml", "AGENTS.md", "README.md"))
    manifest = {path.relative_to(project).as_posix(): file_digest(path)
                for path in sorted(files)}
    atomic_json(destination / "runtime-manifest.json", manifest)
    payload = destination / "payload.tar.gz"
    with tarfile.open(payload, "w:gz") as archive:
        for path in sorted(files):
            archive.add(path, arcname="project/" + path.relative_to(project).as_posix())
        for name in ("plan.json", "runtime-manifest.json"):
            archive.add(destination / name, arcname=name)
    remote_payload = "/scratch_p/nimarano/hpc-forest-r1-pilot-" + session + ".tar.gz"
    receipt = {"scope": SCOPE, "model": MODEL, "effort": EFFORT,
               "session_id": session, "expires_at": time.time() + 3600,
               "historical_campaign_resumption": False,
               "user_request": "Pour voir si tout fonctionne, lance un petit Luna Max, d'un sujet n'importe lequel",
               "plan": {"path": str(destination / "plan.json"),
                        "sha256": file_digest(destination / "plan.json")},
               "payload": {"path": str(payload), "sha256": file_digest(payload)},
               "remote_payload": remote_payload, "channel": None}
    atomic_json(destination / "authorization-pending.json", receipt)
    print(json.dumps({"destination": str(destination), "remote_root": remote_root,
                      "remote_payload": remote_payload, "sha256": file_digest(payload)}))


if __name__ == "__main__":
    main()
