#include <algorithm>
#include <cstdint>
#include <iostream>
#include <utility>
#include <vector>

#if defined(__aarch64__)
#include <arm_neon.h>
#endif

using namespace std;

constexpr int32_t MOD = 1000000007;

#if defined(__aarch64__)
static inline int32x4_t reduce_mod(int32x4_t values, int32x4_t mod_vec) {
    uint32x4_t ge_mask = vcgeq_s32(values, mod_vec);
    uint32x4_t mod_bits = vreinterpretq_u32_s32(mod_vec);
    int32x4_t correction = vreinterpretq_s32_u32(vandq_u32(ge_mask, mod_bits));
    return vsubq_s32(values, correction);
}

static inline int32x4_t scan_four(const vector<int32_t>& previous, int offset,
                                  int32x4_t zero, int32x4_t mod_vec) {
    int32x4_t values = vld1q_s32(previous.data() + offset);
    values = vaddq_s32(values, vextq_s32(zero, values, 3));
    values = reduce_mod(values, mod_vec);
    values = vaddq_s32(values, vextq_s32(zero, values, 2));
    return reduce_mod(values, mod_vec);
}

static inline int32x4_t add_carry(int32x4_t values, int32_t carry,
                                  int32x4_t mod_vec) {
    values = vaddq_s32(values, vdupq_n_s32(carry));
    return reduce_mod(values, mod_vec);
}
#endif

static inline void fill_open_segment(vector<int32_t>& row, int begin, int end) {
    int j = begin;
    int32_t carry = (begin == 0) ? 0 : row[begin - 1];

#if defined(__aarch64__)
    const int32x4_t zero = vdupq_n_s32(0);
    const int32x4_t mod_vec = vdupq_n_s32(MOD);
    for (; j + 8 <= end; j += 8) {
        const int32x4_t first = scan_four(row, j, zero, mod_vec);
        const int32x4_t second = scan_four(row, j + 4, zero, mod_vec);
        const int32x4_t first_result = add_carry(first, carry, mod_vec);
        const int32x4_t second_result =
            add_carry(second, vgetq_lane_s32(first_result, 3), mod_vec);
        vst1q_s32(row.data() + j, first_result);
        vst1q_s32(row.data() + j + 4, second_result);
        carry = vgetq_lane_s32(second_result, 3);
    }
    for (; j + 4 <= end; j += 4) {
        int32x4_t values = scan_four(row, j, zero, mod_vec);
        values = add_carry(values, carry, mod_vec);
        vst1q_s32(row.data() + j, values);
        carry = vgetq_lane_s32(values, 3);
    }
#endif

    for (; j < end; ++j) {
        int32_t value = row[j] + carry;
        if (value >= MOD) value -= MOD;
        row[j] = value;
        carry = value;
    }
}

static int mod_pow(int base, int exponent) {
    int64_t result = 1;
    int64_t factor = base;
    while (exponent > 0) {
        if (exponent & 1) result = result * factor % MOD;
        factor = factor * factor % MOD;
        exponent >>= 1;
    }
    return static_cast<int>(result);
}

static int binomial(int total, int chosen, const vector<int>& factorial,
                    const vector<int>& inverse_factorial) {
    if (chosen < 0 || chosen > total) return 0;
    int64_t result = factorial[total];
    result = result * inverse_factorial[chosen] % MOD;
    result = result * inverse_factorial[total - chosen] % MOD;
    return static_cast<int>(result);
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, m;
    if (!(cin >> n >> m)) return 0;

    vector<vector<int32_t>> blocked_by_row(n);
    for (int k = 0; k < m; ++k) {
        int row, column;
        cin >> row >> column;
        blocked_by_row[row].push_back(column);
    }

    uint64_t obstacle_count = 0;
    for (auto& row : blocked_by_row) {
        sort(row.begin(), row.end());
        row.erase(unique(row.begin(), row.end()), row.end());
        obstacle_count += static_cast<uint64_t>(row.size());
    }

    const bool blocked_start = binary_search(blocked_by_row[0].begin(),
                                              blocked_by_row[0].end(), 0);
    const bool blocked_finish = binary_search(blocked_by_row[n - 1].begin(),
                                               blocked_by_row[n - 1].end(), n - 1);
    if (blocked_start || blocked_finish) {
        cout << 0 << '\n';
        return 0;
    }
    if (n == 1) {
        cout << 1 << '\n';
        return 0;
    }

    const uint64_t sparse_pair_work = obstacle_count * (obstacle_count + 1) / 2;
    const uint64_t dense_cell_work = static_cast<uint64_t>(n) * static_cast<uint64_t>(n);

    if (sparse_pair_work <= dense_cell_work / 1024) {
        vector<pair<int, int>> obstacles;
        obstacles.reserve(static_cast<size_t>(obstacle_count));
        for (int row = 0; row < n; ++row) {
            for (int32_t column : blocked_by_row[row]) {
                obstacles.emplace_back(row, static_cast<int>(column));
            }
        }

        const int max_path_length = 2 * n - 2;
        vector<int> factorial(static_cast<size_t>(max_path_length) + 1);
        vector<int> inverse_factorial(static_cast<size_t>(max_path_length) + 1);
        factorial[0] = 1;
        for (int i = 1; i <= max_path_length; ++i) {
            factorial[i] = static_cast<int>(
                static_cast<int64_t>(factorial[i - 1]) * i % MOD);
        }
        inverse_factorial[max_path_length] =
            mod_pow(factorial[max_path_length], MOD - 2);
        for (int i = max_path_length; i > 0; --i) {
            inverse_factorial[i - 1] = static_cast<int>(
                static_cast<int64_t>(inverse_factorial[i]) * i % MOD);
        }

        vector<int> ways_to_obstacle(obstacles.size());
        for (size_t i = 0; i < obstacles.size(); ++i) {
            const int row = obstacles[i].first;
            const int column = obstacles[i].second;
            int ways = binomial(row + column, row, factorial, inverse_factorial);

            for (size_t j = 0; j < i; ++j) {
                const int previous_row = obstacles[j].first;
                const int previous_column = obstacles[j].second;
                if (previous_row > row || previous_column > column) continue;

                const int segment_paths = binomial(
                    (row - previous_row) + (column - previous_column),
                    row - previous_row, factorial, inverse_factorial);
                const int paths_through_previous = static_cast<int>(
                    static_cast<int64_t>(ways_to_obstacle[j]) * segment_paths % MOD);
                ways -= paths_through_previous;
                if (ways < 0) ways += MOD;
            }
            ways_to_obstacle[i] = ways;
        }

        int answer = binomial(2 * n - 2, n - 1, factorial, inverse_factorial);
        for (size_t i = 0; i < obstacles.size(); ++i) {
            const int row = obstacles[i].first;
            const int column = obstacles[i].second;
            const int segment_paths = binomial(
                (n - 1 - row) + (n - 1 - column), n - 1 - row,
                factorial, inverse_factorial);
            const int paths_through_obstacle = static_cast<int>(
                static_cast<int64_t>(ways_to_obstacle[i]) * segment_paths % MOD);
            answer -= paths_through_obstacle;
            if (answer < 0) answer += MOD;
        }
        cout << answer << '\n';
        return 0;
    }

    vector<int32_t> dp(n, 0);
    dp[0] = 1;
    for (int row = 0; row < n; ++row) {
        int begin = 0;
        for (int32_t blocked_column_value : blocked_by_row[row]) {
            const int blocked_column = static_cast<int>(blocked_column_value);
            fill_open_segment(dp, begin, blocked_column);
            dp[blocked_column] = 0;
            begin = blocked_column + 1;
        }
        fill_open_segment(dp, begin, n);
    }

    cout << dp[n - 1] << '\n';
    return 0;
}
