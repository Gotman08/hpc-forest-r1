#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <vector>

int main(int argc, char** argv) {
    if (argc != 2) return 2;
    const int limit = std::atoi(argv[1]);
    if (limit < 0 || limit > 200000) return 2;

    const int odd_count = (limit + 1) / 2;
    std::vector<unsigned char> is_prime(static_cast<std::size_t>(odd_count), 1);
    if (odd_count > 0) is_prime[0] = 0; // 1 is not prime.

    for (int p = 3; p <= limit / p; p += 2) {
        if (!is_prime[static_cast<std::size_t>(p / 2)]) continue;
        for (int index = (p * p) / 2; index < odd_count; index += p) {
            is_prime[static_cast<std::size_t>(index)] = 0;
        }
    }

    std::uint64_t sum = (limit >= 2) ? 2 : 0;
    for (int index = 1; index < odd_count; ++index) {
        sum += static_cast<std::uint64_t>(2 * index + 1) *
               static_cast<std::uint64_t>(is_prime[static_cast<std::size_t>(index)]);
    }
    std::cout << sum << '\n';
}
