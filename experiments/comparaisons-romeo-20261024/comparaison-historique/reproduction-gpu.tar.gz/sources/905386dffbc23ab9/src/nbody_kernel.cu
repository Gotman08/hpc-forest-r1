// Structure "Array of Structures" (AoS) : intuitive mais naïve sur GPU
// car elle empêche la coalescence parfaite des accès mémoire.
struct Particle {
    float x, y, z;
    float vx, vy, vz;
    float mass;
};

// Kernel CUDA naïf : Simulation gravitationnelle N-Corps (N-Body)
extern "C" __global__ void nbody_step_naive(const Particle* in, Particle* out, int n, float dt) {
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= n) return;

    const float G = 1.0f;
    const float softening = 0.001f;

    float fx = 0.0f;
    float fy = 0.0f;
    float fz = 0.0f;

    // Approche naïve : chaque thread parcourt toutes les particules en mémoire globale
    // sans utiliser de mémoire partagée (__shared__) ni mettre in[i] en registre.
    for (int j = 0; j < n; j++) {
        if (i == j) continue; // Divergence de branche inutile dans la boucle

        float dx = in[j].x - in[i].x;
        float dy = in[j].y - in[i].y;
        float dz = in[j].z - in[i].z;

        float distSq = dx * dx + dy * dy + dz * dz + softening;
        float dist = sqrtf(distSq); // Calcul coûteux (au lieu de rsqrtf)

        float f = (G * in[i].mass * in[j].mass) / (distSq * dist);

        fx += f * dx;
        fy += f * dy;
        fz += f * dz;
    }

    // Intégration d'Euler explicite
    Particle p = in[i];
    const float invMass = 1.0f / p.mass;
    p.vx += (fx * invMass) * dt;
    p.vy += (fy * invMass) * dt;
    p.vz += (fz * invMass) * dt;

    p.x += p.vx * dt;
    p.y += p.vy * dt;
    p.z += p.vz * dt;

    out[i] = p;
}
