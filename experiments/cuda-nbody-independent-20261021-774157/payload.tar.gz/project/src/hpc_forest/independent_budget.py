"""Admission estimates for independent trees sharing an exclusive evaluator."""
from __future__ import annotations

import time
from statistics import median

from .forest import pairwise_mother, research_roles
from .support.budgets import mandatory_final_g


def forecast_independent(db, roles=(), *, now=None):
    config, epoch = db.get("config"), db.get("current_epoch")
    history = db.get("timing_samples", {})
    observed = time.time() if now is None else now
    settings, protocol = config.get("completion", {}), config["protocol"]
    bootstrap = settings.get("initial_model_seconds", 120)
    safety = settings.get("reserve_safety_factor", 1.25)

    def typical(stage, default):
        values = history.get(stage)
        return median(values[-5:]) if values else default

    baseline = typical("evaluation_work:baseline", typical("baseline", 1.0))
    measured_evaluations = [v for key, values in history.items()
                            if key.startswith("evaluation_work:T") for v in values[-5:]]
    generic_evaluation = median(measured_evaluations) if measured_evaluations else baseline

    def evaluation(role):
        return typical("evaluation_work:" + role, generic_evaluation)

    def generation(role):
        # Whole mission wall times used to contain the wait for every other tree.
        # New observations time the worker itself and the exclusive evaluator separately.
        return typical("generation:" + role, bootstrap)

    def confirmation_cost(role):
        work = baseline if role == "baseline" else evaluation(role)
        benchmark = typical("evaluation_benchmark:" + role, None)
        if benchmark is None:
            # No stage timings yet: retain a conservative conversion of whole work.
            return work * max(1, protocol["confirmation_repetitions"] / protocol["repetitions"])
        warmups = protocol["warmups"]
        ratio = (protocol["confirmation_repetitions"] + warmups) / (protocol["repetitions"] + warmups)
        # Compilation and correctness happen once, rather than once per timing repeat.
        return max(0, work - benchmark) + benchmark * ratio

    if history.get("generation:G"):
        final_g = generation("G") + evaluation("G")
        integration_source = "generation:G+evaluation_work:G"
    elif history.get("mission:G"):
        final_g = typical("mission:G", bootstrap + generic_evaluation)
        integration_source = "mission:G"
    else:
        final_g = bootstrap + generic_evaluation
        integration_source = "initial_model_seconds+exclusive_evaluation"
    integration_steps = max(1, len(research_roles(db)) - 1) if pairwise_mother(config) else 1
    integration = integration_steps * final_g

    slots = config["budget"]["confirmation_slots"] + int(mandatory_final_g(config))
    finalists, seen = [], set()
    for candidate in db.archive(epoch):
        if candidate["commit"] not in seen and len(finalists) < slots - 1:
            finalists.append(candidate["role"])
            seen.add(candidate["commit"])
    finalists += ["G"] * (slots - 1 - len(finalists))
    confirmation = typical("confirmation", confirmation_cost("baseline")
                           + sum(confirmation_cost(role) for role in finalists))
    archive = typical("archive", 5.0)
    reserve = safety * (integration + confirmation + archive) + 10

    # Jobs can generate simultaneously but their evaluations occupy the target one
    # at a time. Schedule predicted releases instead of charging another whole wave.
    jobs = []
    active = db.get(f"research_pending:{epoch}", [])
    for node in active:
        role = node["role"]
        remaining_generation = 0.0
        if node["phase"] == "generation":
            nominal = generation(role)
            elapsed = max(0, observed - node["started_at"])
            remaining_generation = max(nominal * 0.1, nominal - elapsed)
        jobs.append((remaining_generation, evaluation(role)))
    jobs.extend((generation(role), evaluation(role)) for role in roles)
    tail = 0.0
    for release, service in sorted(jobs):
        tail = max(tail, release) + service
    next_work = safety * tail
    deadline = db.get("deadline")
    remaining = deadline - observed if deadline is not None else None
    return {
        "observed_at": observed, "target_deadline": deadline,
        "remaining_seconds": remaining, "reserve_seconds": reserve,
        "mother_seconds": typical("mother", bootstrap) if db.get("mother_enabled", False) else 0,
        "final_g_seconds": final_g, "integration_steps": integration_steps,
        "integration_seconds": integration, "integration_estimate_source": integration_source,
        "research_estimate_source": "generation_and_exclusive_evaluation",
        "estimation_policy": "independent_phase_medians",
        "confirmation_seconds": confirmation, "archive_seconds": archive,
        "safety_factor": safety, "next_work_seconds": next_work,
        "pending_roles": list(roles), "inflight_roles": [node["role"] for node in active],
        "predicted_drain_seconds": tail,
        "sample_counts": {key: len(values) for key, values in history.items()},
        "search_admission_deadline": deadline - reserve if deadline is not None else None,
        "can_admit": remaining is None or remaining >= reserve + next_work,
    }
